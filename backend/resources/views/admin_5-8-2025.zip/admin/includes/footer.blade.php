<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-footer__copyright">
        {{ date('Y') }}&nbsp;&copy;&nbsp;<a href="javascript:void(0)"  class="kt-link">{{ config('app.name') }}</a>
    </div>
    Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})
</div>
