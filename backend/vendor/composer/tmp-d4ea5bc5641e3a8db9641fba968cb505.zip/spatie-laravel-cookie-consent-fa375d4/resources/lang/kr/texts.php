<?php

return [
    'message' => '보다 나은 사용자 경험을 위해 쿠키를 허용해 주십시요.',
    'agree' => '쿠키 허용',
];
