<?php

return [
    'message' => 'Pengalaman anda pada situs ini akan meningkat dengan cara mengizinkan cookies.',
    'agree' => 'Izinkan Cookies',
];
