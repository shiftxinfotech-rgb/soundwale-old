<?php

return [
    'message' => "La seva experiència en aquest lloc serà millorada amb l'ús de cookies.",
    'agree' => 'Acceptar',
];
