<?php

return [
    'message' => 'Experiența ta pe acest site va fi îmbunătățită dacă acceptați folosirea de cookie-uri.',
    'agree' => 'Acceptă cookie',
];
