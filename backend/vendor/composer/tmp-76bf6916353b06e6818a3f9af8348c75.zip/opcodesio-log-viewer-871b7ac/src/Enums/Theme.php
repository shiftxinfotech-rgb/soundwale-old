<?php

namespace Opcodes\LogViewer\Enums;

class Theme
{
    public const System = 'System';
    public const Light = 'Light';
    public const Dark = 'Dark';
}
