<?php

namespace Opcodes\LogViewer\Enums;

class SortingOrder
{
    public const Ascending = 'asc';
    public const Descending = 'desc';
}
