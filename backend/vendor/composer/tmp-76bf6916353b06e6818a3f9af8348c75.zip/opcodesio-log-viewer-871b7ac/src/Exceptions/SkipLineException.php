<?php

namespace Opcodes\LogViewer\Exceptions;

class SkipLineException extends \Exception {}
