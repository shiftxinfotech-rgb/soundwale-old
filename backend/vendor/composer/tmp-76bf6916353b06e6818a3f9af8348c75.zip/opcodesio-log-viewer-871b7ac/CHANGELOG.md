# Changelog

All notable changes to `log-viewer` will be documented in this file.
